package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.*;
import java.io.*;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private TextView textViewGas, textViewWater, textViewTotal;
    private RequestQueue mQueue;
    private EditText boilerTemp;
    private String url = "https://showercontroller.s3.eu-central-1.amazonaws.com/data.json";
    private double ratio_hot_cold_water;
    private double mass_hot_water, water_flow, water_used, water_cost;
    private double gas_used, gas_cost, heat, total_cost;
    private double volume;
    private ToggleButton boilerButton;

    private double density_water = 0.997;
    private int specific_heat_water = 4182;
    private int energy_density_gas = 31700000;
    private double water_price = 0.00089;
    private double gas_price = 3.94;
    private double T_cold = 15;
    private double T_hot;
    private double T_shower;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        textViewTotal = findViewById(R.id.textViewTotal);
        textViewWater = findViewById(R.id.textViewWater);
        textViewGas = findViewById(R.id.textViewGas);
        ToggleButton boilerButton = findViewById(R.id.toggleButtonBoiler);
        EditText boilerTemp = findViewById(R.id.editTextBoilerTemp);

        Button buttonParse = findViewById(R.id.button_parse);
        //getKNMI();

        buttonParse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String value = boilerTemp.getText().toString();
                T_hot = Integer.parseInt(value);
                //T_cold = getKNMI();

                jsonParse();
                jsonParseVolume();
                // jsonParseTime();
                costCalculation();
                textViewGas.setText(String.valueOf("Gas Cost: €" + String.valueOf(round(gas_cost, 2))));
                textViewWater.setText(String.valueOf("Water Cost: €" + String.valueOf(round(water_cost, 2))));
                textViewTotal.setText(String.valueOf("Total Cost: €" + String.valueOf(round(total_cost, 2))));
            }
        });


    }

    public void jsonParse() {

        mQueue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            //JSONArray jsonArray = response.getJSONArray("");
                            //JSONObject flowMeter = jsonArray.getJSONObject(0);
                            double temp = response.getDouble("temp");
                            T_shower = temp;
                            textView.setText("Shower Temperature: " + String.valueOf(round(temp, 2) + " °C"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                            textView.setText("Error1");
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                textView.setText("Error2");
            }
        });
        mQueue.add(request);
    }

    public void jsonParseVolume() {

        mQueue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            //JSONArray jsonArray = response.getJSONArray("");
                            //JSONObject flowMeter = jsonArray.getJSONObject(0);
                            volume = response.getDouble("volume");
                            //textView3.setText(String.valueOf(volume));
                            water_used = volume;

                        } catch (JSONException e) {
                            e.printStackTrace();
                            textViewGas.setText("Error1");
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                textView.setText("Error2");
            }
        });
        mQueue.add(request);
    }

    public void jsonParseTime() {

        mQueue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            //JSONArray jsonArray = response.getJSONArray("");
                            //JSONObject flowMeter = jsonArray.getJSONObject(0);
                            int timestamp = response.getInt("timestamp");
                            //textView.setText(String.valueOf(timestamp));

                        } catch (JSONException e) {
                            e.printStackTrace();
                            textView.setText("Error1");
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                textView.setText("Error2");
            }
        });
        mQueue.add(request);
    }

    public void costCalculation() {
        ratio_hot_cold_water = (T_cold - T_shower) / (T_shower - T_hot);
        mass_hot_water = (water_used * density_water * ratio_hot_cold_water) / (1 + ratio_hot_cold_water);
        heat = mass_hot_water * specific_heat_water * (T_hot - T_cold);
        gas_used = heat / energy_density_gas;
        water_cost = water_used * water_price;
        gas_cost = gas_used * gas_price;

        total_cost = water_cost + gas_cost;


    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}