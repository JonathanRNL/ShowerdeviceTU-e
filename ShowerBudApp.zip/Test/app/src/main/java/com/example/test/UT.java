package com.example.test;

public class UT {
	public static void main(String[] args) {
		StringBuffer sb = urllib.urlopen("https://www.knmi.nl/nederland-nu/weer/actueel-weer/actuele-bodemtemperaturen");
		System.out.println(sb.substring(sb.indexOf("De Bilt")+196,sb.indexOf("De Bilt")+200));
	}
}

